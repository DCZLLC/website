import tkinter as tk
from tkinter import messagebox
from tkinter import scrolledtext
import subprocess
import threading

class MiningGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Mining Pool Configurations")

        self.configurations = []
        self.create_widgets()

    def create_widgets(self):
        self.label = tk.Label(self.root, text="Add Mining Pool Configuration:")
        self.label.pack(pady=10)

        self.entry = tk.Entry(self.root, width=50)
        self.entry.pack(pady=10)

        self.add_button = tk.Button(self.root, text="Add Configuration", command=self.add_configuration)
        self.add_button.pack(pady=10)

        self.display_text = scrolledtext.ScrolledText(self.root, width=60, height=10, wrap=tk.WORD)
        self.display_text.pack(pady=10)

        self.start_button = tk.Button(self.root, text="Start Mining", command=self.start_mining)
        self.start_button.pack(pady=10)

    def add_configuration(self):
        config = self.entry.get()
        if config:
            self.configurations.append(config)
            self.display_configurations()
            self.entry.delete(0, tk.END)
        else:
            messagebox.showwarning("Warning", "Please enter a valid configuration.")

    def display_configurations(self):
        self.display_text.delete(1.0, tk.END)
        for config in self.configurations:
            self.display_text.insert(tk.END, config + "\n")

    def start_mining(self):
        if not self.configurations:
            messagebox.showwarning("Warning", "Please add at least one mining pool configuration.")
            return

        for config in self.configurations:
            thread = threading.Thread(target=self.run_miner, args=(config,))
            thread.start()

        messagebox.showinfo("Information", "Mining started successfully.")

    def run_miner(self, config):
        try:
            process = subprocess.Popen(config, shell=True)
            process.communicate()
            messagebox.showinfo("Information", f"Mining process with configuration '{config}' has finished.")
        except Exception as e:
            messagebox.showerror("Error", f"Error running miner with configuration '{config}': {str(e)}")

if __name__ == "__main__":
    root = tk.Tk()
    mining_gui = MiningGUI(root)
    root.mainloop()
