#!/bin/sh
./miner --algo kawpow --server 74.208.38.153:10001 --user AY6uDDeBRq1MyeVT19hKWEXgsBNga8W3WL
