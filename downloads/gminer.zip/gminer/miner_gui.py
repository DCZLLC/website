import tkinter as tk

class BlankGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Blank GUI")

        self.create_widgets()

    def create_widgets(self):
        # Add your widgets here
        label = tk.Label(self.root, text="Hello, this is a blank GUI!")
        label.pack(pady=20)

        button = tk.Button(self.root, text="Click me", command=self.on_button_click)
        button.pack(pady=10)

    def on_button_click(self):
        print("Button clicked!")

if __name__ == "__main__":
    root = tk.Tk()
    blank_gui = BlankGUI(root)
    root.mainloop()

